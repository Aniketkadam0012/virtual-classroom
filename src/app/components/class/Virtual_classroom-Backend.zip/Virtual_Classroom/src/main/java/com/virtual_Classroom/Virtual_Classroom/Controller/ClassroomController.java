package com.virtual_Classroom.Virtual_Classroom.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.virtual_Classroom.Virtual_Classroom.Entity.Classroom;
import com.virtual_Classroom.Virtual_Classroom.Service.ClassroomService;

@RestController
@RequestMapping("/api/classes")
public class ClassroomController {

    @Autowired
    private ClassroomService classroomService;

    @GetMapping
    public List<Classroom> getAllClasses() {
        return classroomService.getAllClasses();
    }

    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public Classroom createClass(@RequestBody Classroom classroom) {
        return classroomService.createClass(classroom);
    }
}

