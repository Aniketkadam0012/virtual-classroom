package com.virtual_Classroom.Virtual_Classroom.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.virtual_Classroom.Virtual_Classroom.Entity.Classroom;

@Repository
public interface ClassroomRepository extends JpaRepository<Classroom, Long> {
}