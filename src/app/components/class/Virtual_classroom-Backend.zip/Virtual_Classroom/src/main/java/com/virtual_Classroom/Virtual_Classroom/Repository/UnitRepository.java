package com.virtual_Classroom.Virtual_Classroom.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.virtual_Classroom.Virtual_Classroom.Entity.Unit;

@Repository
public interface UnitRepository extends JpaRepository<Unit, Long> {
}
