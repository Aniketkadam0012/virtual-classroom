package com.virtual_Classroom.Virtual_Classroom.Service;

import java.util.List;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtual_Classroom.Virtual_Classroom.Repository.SessionRepository;

@Service
public class SessionService {
    @Autowired
    private SessionRepository sessionRepository;

    public List<Session> getAllSessionsForClass(Long classId) {
        return sessionRepository.findAllByClassId(classId);
    }

    public Session addSession(Session session) {
        return sessionRepository.save(session);
    }
}

