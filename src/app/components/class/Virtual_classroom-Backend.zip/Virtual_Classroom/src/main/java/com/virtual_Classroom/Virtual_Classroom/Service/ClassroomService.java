package com.virtual_Classroom.Virtual_Classroom.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtual_Classroom.Virtual_Classroom.Entity.Classroom;
import com.virtual_Classroom.Virtual_Classroom.Repository.ClassroomRepository;

@Service
public class ClassroomService {
    @Autowired
    private ClassroomRepository classroomRepository;

    public List<Classroom> getAllClasses() {
        return classroomRepository.findAll();
    }

    public Classroom createClass(Classroom classroom) {
        return classroomRepository.save(classroom);
    }
}

