package com.virtual_Classroom.Virtual_Classroom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VirtualClassroomApplicationTests {

	@Test
	void contextLoads() {
	}

}
